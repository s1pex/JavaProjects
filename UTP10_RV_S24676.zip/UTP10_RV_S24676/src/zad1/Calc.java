/**
 *
 *  @author Raksha Vladyslav S24676
 *
 */

package zad1;


import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.function.BiFunction;
import java.util.Map;
import java.util.HashMap;


public class Calc {
    private static final Map<String, BiFunction<BigDecimal, BigDecimal, BigDecimal>> operations = new HashMap<>();
    static {
        operations.put("+", BigDecimal::add);
        operations.put("-", BigDecimal::subtract);
        operations.put("*", BigDecimal::multiply);
        operations.put("/", (num1, num2) -> num1.divide(num2, 7, RoundingMode.HALF_UP));
    }

    public String doCalc(String cmd) {
        String[] parts = cmd.split("\\s+");
        if (parts.length != 3) {
            return "Invalid command to calc";
        }
        BigDecimal num1 = new BigDecimal(parts[0]);
        BigDecimal num2 = new BigDecimal(parts[2]);
        String operator = parts[1];

        BiFunction<BigDecimal, BigDecimal, BigDecimal> operation = operations.get(operator);
        if (operation == null) {
            return "Invalid operator";
        }

        BigDecimal result = operation.apply(num1, num2);
        return result.toString();
    }
}
