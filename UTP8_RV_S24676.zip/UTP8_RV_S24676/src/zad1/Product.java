package zad1;

public class Product {
    double id;
    double weight;
    public Product(double id, double weight){
        this.id = id;
        this.weight = weight;
    }

    public double getWeight() {
        return weight;
    }
}
