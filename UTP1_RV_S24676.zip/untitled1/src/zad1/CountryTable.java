package zad1;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CountryTable extends DefaultTableCellRenderer {

    String fileOfCountires;
    String[] countriesCapitalPopulation;

    public CountryTable(String countriesFileName) {

        fileOfCountires = countriesFileName;

    }

    public JTable create() throws IOException {

        FileReader fileReader = new FileReader(fileOfCountires);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        DefaultTableModel defaultTableModel = new DefaultTableModel();

        String header = bufferedReader.readLine().trim();
        String[] headerName = header.split("\\t");
        defaultTableModel.setColumnIdentifiers(headerName);

        for(String data = bufferedReader.readLine(); data != null; data = bufferedReader.readLine()){
            countriesCapitalPopulation = data.split("\\t");
            defaultTableModel.insertRow(0, new Object[] {countriesCapitalPopulation[0],
            countriesCapitalPopulation[1],countriesCapitalPopulation[2],
            Integer.parseInt(countriesCapitalPopulation[3])});
        }

        JTable jtable = new JTable(defaultTableModel);

        jtable.getColumnModel().getColumn(3).setCellRenderer((table, value, isSelected, hasFocus, row, column) -> {
            JLabel jLabel = new JLabel(value.toString());
            if((int)value > 20000){
                jLabel.setForeground(Color.red);
            }
            return jLabel;
        });

        return jtable;
    }
}
