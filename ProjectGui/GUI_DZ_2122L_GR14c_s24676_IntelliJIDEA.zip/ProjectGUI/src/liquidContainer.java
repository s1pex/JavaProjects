class liquidContainer
        extends basicContainer {

    String typeOfLiquid;

    public liquidContainer(String typeOfContainer,String Sender, String tare, String security, int totalWeight, int weightOfProducts, String typeOfLiquid, String InfoOfCertificates, String nameOfContainer) {
        super(typeOfContainer,Sender, tare, security, totalWeight, weightOfProducts, InfoOfCertificates, nameOfContainer);
        this.typeOfLiquid = typeOfLiquid;
    }
}