
import java.io.FileNotFoundException;
import java.util.*;
import java.time.LocalDate;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.File;

public class Ship {

    static int maxWeigthOnShip;
    static int maxNumOfAllContainers;
    int maxNumumOfDangerousOrToxicContainers = 3;
    int maxNumOfBigContainers;
    int maxNumOfContainersWithElectricity;
    String name;
    String port;
    String lokalizationOfTransport;
    String Destination;
    int numberOfAlreadyToppedUpContainers;
    int privateNumber;

    Ship(String name, String port, String lokalizationOfTransport, String Destination, int maxNumOfDangerousOrToxicContainers,
         int maxNumOfBigContainers, int maxNumOfContainersWithElectricity, int maxNumOfAllContainers, int maxWeigthOnShip, int numberOfAlreadyToppedUpContainers) throws IOException {
        this.name = name;
        this.port = port;
        this.lokalizationOfTransport = lokalizationOfTransport;
        this.Destination = Destination;
        this.maxNumumOfDangerousOrToxicContainers = maxNumOfDangerousOrToxicContainers;
        this.maxNumOfBigContainers = maxNumOfBigContainers;
        this.maxNumOfAllContainers = maxNumOfAllContainers;
        this.maxNumOfContainersWithElectricity = maxNumOfContainersWithElectricity;
        this.maxWeigthOnShip = maxWeigthOnShip;
        this.numberOfAlreadyToppedUpContainers = numberOfAlreadyToppedUpContainers;
        this.privateNumber = getNumberOfShip();
    }

    public static int getNumberOfShip() {
        Random rand = new Random();
        int n = rand.nextInt(100000);
        return n;
    }

    public String toString() {

        return "Name of a ship: " + name + "\n" + "Port: " + port + "\n" + "Lokalization: " + lokalizationOfTransport + "\n" + "Destination: "
                + Destination + "." + "\n" + "Maximum number of dangerous or toxic containers : " + maxNumumOfDangerousOrToxicContainers + "\n" + "Maximum number of big containers : " +
                maxNumOfBigContainers + "\n" + "Maximum number of all containers : " + maxNumOfAllContainers + "." + "\n" + "Maximum number of containers with electricity : " +
                maxNumOfContainersWithElectricity + "\n" + "Maximum weight on the ship : " + maxWeigthOnShip + "\n" + "Number of already topped up containers : " + numberOfAlreadyToppedUpContainers + "."
                + "\n" + "Private number of a ship is : " + privateNumber + "\n";

    }
static boolean firstTime = true;
    public static void menu() throws IOException {

        System.out.println("Menu" + "\n" + "[1] Order a new ship" + "\n" + "[2] Top up with containers" + "\n" + "[3] List of ordered ships" + "\n" +
                "[4] List of topped up containers" + "\n" + "[5] List of containers in a shop" + "\n" + "[6] List of containers on the wagon" + "\n" + "[7] Unload containers to the shop or wagon "
                + "\n" +"[0] Exit the programm");
        boolean ifAdded = true;
        Scanner scan = new Scanner(System.in);
        int s1 = scan.nextInt();

        switch (s1) {
            case 1:
                getNewShip();
                menu();
                break;

            case 2:
                    topUpWithContainers(true);

                menu();
                break;

            case 3:
                    if(firstTime){
                    getShipsList();}
                    firstTime = false;
                    System.out.println(shipsList);
                    menu();
                break;

            case 4:
                if (containerList.isEmpty()) {
                    System.out.println("[!] You dont have any topped up containers at the moment");
                } else {

                    for(int i=0;i<containerList.size();i++){
                        System.out.println(containerList.get(i));
                    }
                }
                menu();

                break;

            case 5:

                for(int i=0;i<shopList.size();i++){
                    System.out.println(shopList.get(i));
                }
                menu();

                break;

            case 6:

                for(int i=0;i<wagonList.size();i++){
                    System.out.println(wagonList.get(i));
                }
                menu();

                break;

            case 7:
                unload();

                break;

            case 0:

                File file = new File ("/Users/rakshavladyslav/Desktop/ships.txt");
                PrintWriter printWriter = new PrintWriter (file);
                printWriter.write(String.valueOf(shipsList));
                Scanner s = new Scanner(file);
                String line = s.nextLine();
                for (int i = 0; i < file.length(); i++){
                    if (line.charAt(i) == '[' || line.charAt(i) == ']' ) {
                        line.replace('[', ' ');
                        line.replace(']', ' ');
                    }
                }
                printWriter.close();

                File file1 = new File ("/Users/rakshavladyslav/Desktop/containers.txt");
                PrintWriter printWriter1 = new PrintWriter (file1);
                printWriter1.write(String.valueOf(containerList));
                printWriter1.close();

                File file2 = new File ("/Users/rakshavladyslav/Desktop/sender.txt");
                PrintWriter printWriter2 = new PrintWriter (file2);
                printWriter2.write(String.valueOf(senderList));
                printWriter2.close();

                System.exit(0);
        }
    }

    public static List<Ship> shipsList = new ArrayList<Ship>();


    static List<Ship> getShipsList() throws IOException {

        Ship ship1 = new Ship("Mary", "Odessa", "Portu", "Ukraine",
                3, 20, 5,
                100, 500000, 0);
        shipsList.add(ship1);


        Ship ship2 = new Ship("Argo", "Odessa", "Poland", "Ukraine",
                3, 15, 10,
                70, 350000, 0);
        shipsList.add(ship2);


        Ship ship3 = new Ship("Balta", "Odessa", "Turkey", "Ukraine",
                3, 15, 3,
                80, 400000, 0);
        shipsList.add(ship3);


        Ship ship4 = new Ship("Pryluky", "Odessa", "Egypt", "Ukraine",
                3, 20, 2,
                120, 550000, 0);
        shipsList.add(ship4);


        Ship ship5 = new Ship("Sagajdachny", "Odessa", "Romania", "Ukraine",
                3, 20, 5,
                100, 4700000, 0);
        shipsList.add(ship5);

        return shipsList;
    }


    public static void getNewShip() throws IOException {

        int maxNumumOfDangerousOrToxicContainers = 3;
        int numberOfAlreadyToppedUpContainers = 0;
        System.out.println("Who is a name of a ship?");
        Scanner name = new Scanner(System.in);
        String nameOfShip = name.nextLine();
        System.out.println("What is the name of the port?");
        Scanner tare = new Scanner(System.in);
        String nameOfPort = tare.nextLine();
        System.out.println("What is the localization?");
        Scanner security = new Scanner(System.in);
        String localization = security.nextLine();
        System.out.println("What is the destination?");
        Scanner weigth = new Scanner(System.in);
        String destination = weigth.nextLine();
        System.out.println("What is the maximum number of big containers");
        Scanner numOfBigContainers = new Scanner(System.in);
        int maxNumOfBigContainers = numOfBigContainers.nextInt();
        System.out.println("What is the maximum number of all containers?");
        Scanner maxNumOfAllContainers11 = new Scanner(System.in);
        int maxNumOfAllContainers = maxNumOfAllContainers11.nextInt();
        System.out.println("What is the maximum number of all containers with electricity?");
        Scanner containerWithElectricity = new Scanner(System.in);
        int maxNumOfContainersWithElectricity = containerWithElectricity.nextInt();
        System.out.println("What is the max Weight on ship?");
        Scanner maxWeigth = new Scanner(System.in);
        int maxWeigthOnShip = maxWeigth.nextInt();
        System.out.print("Ship private number is : ");
        System.out.println(getNumberOfShip());

        Ship sp = new Ship(nameOfShip, nameOfPort, localization, destination, maxNumumOfDangerousOrToxicContainers,
                maxNumOfBigContainers, maxNumOfAllContainers, maxNumOfContainersWithElectricity, maxWeigthOnShip, numberOfAlreadyToppedUpContainers);
        shipsList.add(sp);
        System.out.println();



        System.out.println("Do you want to create one more ship?");
        Scanner ans1 = new Scanner(System.in);
        String answer = ans1.nextLine();
        if (answer.equals("yes") || answer.equals("Yes") || answer.equals("YES")) {
            getNewShip();
        } else {
            menu();
        }
    }

    public static List<Container> containerList = new ArrayList();



    public static void topUpWithContainers(boolean firstTime) throws IOException {

        if(firstTime){
        Sender();
        }

        int maxWeigth = maxWeigthOnShip;
        int totalOfAllContainers = 0;
        int numOfContainers = 0;

        for (Ship ship : shipsList) {
            System.out.println("Name of a ship: " + ship.name + "\n" + "Port: " + ship.port + "\n" + "Lokalization: " + ship.lokalizationOfTransport + "\n" + "Destination: "
                    + ship.Destination + "." + "\n" + "Maximum number of dangerous or toxic containers : " + ship.maxNumumOfDangerousOrToxicContainers + "\n" + "Maximum number of big containers : " +
                    ship.maxNumOfBigContainers + "\n" + "Maximum number of all containers : " + ship.maxNumOfAllContainers + "." + "\n" + "Maximum number of containers with electricity : " +
                    ship.maxNumOfContainersWithElectricity + "\n" + "Maximum weight on the ship : " + ship.maxWeigthOnShip + "\n" + "Number of already topped up containers : " + ship.numberOfAlreadyToppedUpContainers + "."
                    + "\n" + "Private number of a ship is : " + ship.privateNumber + "\n");
        }
        try{
        System.out.println("[!] What of this ships you want to top up?");

        Scanner tmp = new Scanner(System.in);
        int cont = tmp.nextInt();
        System.out.println("You will top up this container : ");
        System.out.println(shipsList.get(cont - 1));

        System.out.println("What types of containers you want to top up?");
        System.out.println("You can top up with such types: 1)Basic; 2)Heavy; 3)Cooling; 4)With liquid; 5)With explosive goods; 6)With toxic solid goods or liquid goods.");
        System.out.println("Type down the variant from 1 to 6");
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();

        switch (n) {
            case 1:
                System.out.println("How many containers of this type you want to top up");
                Scanner scan1 = new Scanner(System.in);
                int n1 = scan1.nextInt();
                int q = 0;

                if (numOfContainers + n1 <= Ship.maxNumOfAllContainers) {
                    for (int i = 0; i < n1; i++) {

                        System.out.println("Who is a sender?");
                        Scanner name = new Scanner(System.in);
                        String sender = name.nextLine();
                        System.out.println("What is tare?");
                        Scanner tare = new Scanner(System.in);
                        String goods = tare.nextLine();
                        System.out.println("What Security you use?");
                        Scanner security = new Scanner(System.in);
                        String securityType = security.nextLine();
                        System.out.println("What is the total weight [In kilograms] ?");
                        Scanner weigth = new Scanner(System.in);
                        int total = weigth.nextInt();
                        System.out.println("What is the weight of goods [In kilograms] ?");
                        Scanner weigthOfGoods = new Scanner(System.in);
                        int totalGoods = weigthOfGoods.nextInt();
                        System.out.println("Do you have any certificates on your goods?");
                        Scanner sertificates = new Scanner(System.in);
                        String sertificatesTypes = sertificates.nextLine();
                        String nameOfContainer = shipsList.get(cont - 1).name;
                        String typeOfContainer = "Basic Container";

                        if (totalOfAllContainers + total < maxWeigth) {
                            basicContainer bc = new basicContainer(typeOfContainer, sender, goods, securityType, total, totalGoods, sertificatesTypes, nameOfContainer);
                            containerList.add(bc);


                            q++;

                        } else {
                            System.out.println("[!] You have exceeded the weigth limit! We cannot top up that last container.");
                            System.out.println();
                            topUpWithContainers(false);
                        }
                    }
                    System.out.println("Do you want to top up another containers");
                    Scanner answer = new Scanner(System.in);
                    String ans = answer.nextLine();
                    if (ans.equals("yes") || ans.equals("Yes")) {
                        topUpWithContainers(false);
                    }

                    System.out.print(containerList);
                } else {
                    System.out.println("We are not able to top up such ammount of containers");
                }
menu();
                break;
            case 2:
                System.out.println("How many containers of this type you want to top up");
                Scanner scan2 = new Scanner(System.in);
                int n2 = scan2.nextInt();
                int q1 = 0;

                if (numOfContainers + n2 <= Ship.maxNumOfAllContainers) {
                    for (int i = 0; i < n2; i++) {
                        String typeOfContainer = "Heavy Container";
                        System.out.println("Who is a sender?");
                        Scanner name = new Scanner(System.in);
                        String sender = name.nextLine();
                        System.out.println("What is tare?");
                        Scanner tare = new Scanner(System.in);
                        String goods = tare.nextLine();
                        System.out.println("What Security you use?");
                        Scanner security = new Scanner(System.in);
                        String securityType = security.nextLine();
                        System.out.println("What is the total weigth [In kilograms] ?");
                        Scanner weigth = new Scanner(System.in);
                        int total = weigth.nextInt();
                        System.out.println("What is the wieght of goods [In kilograms] ?");
                        Scanner weigthOfGoods = new Scanner(System.in);
                        int totalGoods = weigthOfGoods.nextInt();
                        System.out.println("What type of goods do you want to transport?");
                        Scanner type = new Scanner(System.in);
                        String goodsType = type.nextLine();
                        System.out.println("Do you have any sertificates on your goods?");
                        Scanner sertificates = new Scanner(System.in);
                        String sertificatesTypes = sertificates.nextLine();
                        String nameOfContainer = shipsList.get(cont - 1).name;

                        if (totalOfAllContainers + total < maxWeigth) {
                            heavyContainer hc = new heavyContainer(typeOfContainer, sender, goods, securityType, total, totalGoods, goodsType, sertificatesTypes, nameOfContainer);
                            hc.toString();
                            containerList.add(hc);

                            q1++;
                        } else {
                            System.out.println("[!] You have exceeded the weigth limit! We cannot top up that last container.");
                            System.out.println();
                            topUpWithContainers(false);
                        }
                    }

                    System.out.println("Do you want to top up another containers");
                    Scanner answer = new Scanner(System.in);
                    String ans = answer.nextLine();
                    if (ans.equals("yes") || ans.equals("Yes")) {
                        topUpWithContainers(false );
                    }

                    System.out.println("Topped up container on this ship : " + shipsList.get(cont - 1));
                    System.out.println(containerList);

                } else {
                    System.out.println("We are not able to top up such ammount of containers");
                }
                break;
            case 3:

                System.out.println("How many containers of this type you want to top up");
                Scanner scan3 = new Scanner(System.in);
                int n3 = scan3.nextInt();
                int q2 = 0;
                if (numOfContainers + n3 <= Ship.maxNumOfAllContainers) {
                    for (int i = 0; i < n3; i++) {
                        String typeOfContainer = "Cooling Container";
                        System.out.println("Who is a sender?");
                        Scanner name = new Scanner(System.in);
                        String sender = name.nextLine();
                        System.out.println("What is tare?");
                        Scanner tare = new Scanner(System.in);
                        String goods = tare.nextLine();
                        System.out.println("What id the type of your goods?");
                        Scanner typeG = new Scanner(System.in);
                        String typeOfGoods = typeG.nextLine();
                        System.out.println("What Security you use?");
                        Scanner security = new Scanner(System.in);
                        String securityType = security.nextLine();
                        System.out.println("What is the total weigth [In kilograms] ?");
                        Scanner weigth = new Scanner(System.in);
                        int total = weigth.nextInt();
                        System.out.println("What is the wieght of goods [In kilograms] ?");
                        Scanner weigthOfGoods = new Scanner(System.in);
                        int totalGoods = weigthOfGoods.nextInt();
                        System.out.println("What type of cooling do you have?");
                        Scanner type = new Scanner(System.in);
                        String typeOfCooling = type.nextLine();
                        System.out.println("Do you have any sertificates on your cooling system?");
                        Scanner sertificates = new Scanner(System.in);
                        String sertificatesTypes = sertificates.nextLine();
                        String nameOfContainer = shipsList.get(cont - 1).name;

                        System.out.println("Do you have connected the electricity in that container?");

                        Scanner scan11 = new Scanner(System.in);
                        String energy = scan11.nextLine();

                        if (energy.equals("yes") || energy.equals("Yes")) {
                            System.out.println("Everything with electrical container is good, you have an electricity");
                            System.out.println();
                            if (totalOfAllContainers + total < maxWeigth) {
                                coolingContainer cc = new coolingContainer(typeOfContainer, sender, goods, typeOfGoods, securityType, total, totalGoods, typeOfCooling, sertificatesTypes, nameOfContainer);
                                cc.toString();
                                containerList.add(cc);
                                q2++;
                            } else {
                                System.out.println("[!] You have exceeded the weigth limit! We cannot top up that last container.");
                                System.out.println();
                                topUpWithContainers(false);
                            }
                        } else {
                            System.out.println("You need to connect container to electricity");
                            System.out.println();
                        }
                    }
                    System.out.println("Do you want to top up another containers");
                    Scanner answer = new Scanner(System.in);
                    String ans = answer.nextLine();
                    if (ans.equals("yes") || ans.equals("Yes")) {
                        topUpWithContainers(false);
                    }

                    System.out.println("Topped up container on this ship : " + shipsList.get(cont - 1));
                    System.out.println(containerList);

                } else {
                    System.out.println("We are not able to top up such ammount of containers");
                }
                break;
            case 4:
                System.out.println("How many containers of this type you want to top up");
                Scanner scan4 = new Scanner(System.in);
                int n4 = scan4.nextInt();
                if (numOfContainers + n4 <= Ship.maxNumOfAllContainers) {
                    for (int i = 0; i < n4; i++) {
                        String typeOfContainer = "Container with liquid";
                        System.out.println("Who is a sender?");
                        Scanner name = new Scanner(System.in);
                        String sender = name.nextLine();
                        System.out.println("What is tare?");
                        Scanner tare = new Scanner(System.in);
                        String goods = tare.nextLine();
                        System.out.println("What Security you use?");
                        Scanner security = new Scanner(System.in);
                        String securityType = security.nextLine();
                        System.out.println("What is the total weigth [In kilograms] ?");
                        Scanner weigth = new Scanner(System.in);
                        int total = weigth.nextInt();
                        System.out.println("What is the wieght of goods [In kilograms] ?");
                        Scanner weigthOfGoods = new Scanner(System.in);
                        int totalGoods = weigthOfGoods.nextInt();
                        System.out.println("Do type of liwuid do you have?");
                        Scanner type = new Scanner(System.in);
                        String liquidType = type.nextLine();
                        System.out.println("Do you have any sertificates on your goods?");
                        Scanner sertificates = new Scanner(System.in);
                        String sertificatesTypes = sertificates.nextLine();
                        String nameOfContainer = shipsList.get(cont - 1).name;


                        if (totalOfAllContainers + total < maxWeigth) {
                            liquidContainer lc = new liquidContainer(typeOfContainer, sender, goods, securityType, total, totalGoods, liquidType, sertificatesTypes, nameOfContainer);
                            lc.toString();
                            containerList.add(lc);

                        } else {
                            System.out.println("[!] You have exceeded the weigth limit! We cannot top up that last container.");
                            System.out.println();
                            topUpWithContainers(false);
                        }
                    }

                    System.out.println("Do you want to top up another containers");
                    Scanner answer = new Scanner(System.in);
                    String ans = answer.nextLine();
                    if (ans.equals("yes") || ans.equals("Yes")) {
                        topUpWithContainers(false);
                    }

                    System.out.println("Topped up container on this ship : " + shipsList.get(cont - 1));
                    System.out.println(containerList);

                } else {
                    System.out.println("We are not able to top up such ammount of containers");
                }
                break;
            case 5:
                System.out.println("How many containers of this type you want to top up(Maximum ammount is 3 containers of such type)");
                Scanner scan5 = new Scanner(System.in);
                int n5 = scan5.nextInt();
                int q4 = 0;
                if (numOfContainers + n5 <= Ship.maxNumOfAllContainers) {
                    if (n5 <= 3) {
                        for (int i = 0; i < n5; i++) {
                            String typeOfContainer = "With explosive goods";
                            System.out.println("Who is a sender?");
                            Scanner name = new Scanner(System.in);
                            String sender = name.nextLine();
                            System.out.println("What is tare?");
                            Scanner tare = new Scanner(System.in);
                            String goods = tare.nextLine();
                            System.out.println("What Security you use?");
                            Scanner security = new Scanner(System.in);
                            String securityType = security.nextLine();
                            System.out.println("What is the total weigth [In kilograms] ?");
                            Scanner weigth = new Scanner(System.in);
                            int total = weigth.nextInt();
                            System.out.println("What is the wieght of goods [In kilograms] ?");
                            Scanner weigthOfGoods = new Scanner(System.in);
                            int totalGoods = weigthOfGoods.nextInt();
                            System.out.println("Do type of good you want to transport?");
                            Scanner typeG = new Scanner(System.in);
                            String typeOfGoods = typeG.nextLine();
                            System.out.println("Do type of explosive material do you have?");
                            Scanner type = new Scanner(System.in);
                            String typeOfExplosiveMaterial = type.nextLine();
                            System.out.println("Do you have any sertificates on your goods?");
                            Scanner sertificates = new Scanner(System.in);
                            String sertificatesTypes = sertificates.nextLine();
                            String nameOfContainer = shipsList.get(cont - 1).name;

                            if (totalOfAllContainers + total < maxWeigth) {
                                explosiveContainer ec = new explosiveContainer(typeOfContainer, sender, goods, securityType, total, totalGoods, typeOfGoods, typeOfExplosiveMaterial, sertificatesTypes, nameOfContainer);
                                ec.toString();
                                containerList.add(ec);
                                q4++;

                            } else {
                                System.out.println("[!] You have exceeded the weigth limit! We cannot top up that last container.");
                                System.out.println();
                                topUpWithContainers(false);
                            }
                        }
                    } else {
                        System.out.println("We cannot carry such a big ammount of containers because its very dangerous!");
                    }

                    System.out.println("Do you want to top up another containers");
                    Scanner answer = new Scanner(System.in);
                    String ans = answer.nextLine();
                    if (ans.equals("yes") || ans.equals("Yes")) {
                        topUpWithContainers(false);
                    }

                    System.out.println("Topped up container on this ship : " + shipsList.get(cont - 1));
                    System.out.println(containerList);

                } else {
                    System.out.println("We are not able to top up such ammount of containers");
                }
                break;
            case 6:
                System.out.println("How many containers of this type you want to top up( Maximum ammount is 3 )");
                Scanner scan6 = new Scanner(System.in);
                int n6 = scan6.nextInt();
                int q5 = 0;
                if (numOfContainers + n6 <= Ship.maxNumOfAllContainers) {
                    if (n6 <= 3) {
                        System.out.println("What type of container you want to top up");
                        System.out.println("You have 2 options: 1)With solid toxic goods; 2)With liquid toxic goods");
                        System.out.println("Write down number from 1 to 2");
                        Scanner typeOfContainers = new Scanner(System.in);
                        int type = typeOfContainers.nextInt();

                        switch (type) {
                            case 1:
                                for (int i = 0; i < n6; i++) {
                                    String typeOfContainer = "With toxic solid goods";
                                    System.out.println("Who is a sender?");
                                    Scanner name = new Scanner(System.in);
                                    String sender = name.nextLine();
                                    System.out.println("What is tare?");
                                    Scanner tare = new Scanner(System.in);
                                    String goods = tare.nextLine();
                                    System.out.println("What Security you use?");
                                    Scanner security = new Scanner(System.in);
                                    String securityType = security.nextLine();
                                    System.out.println("What is the total weigth [In kilograms] ?");
                                    Scanner weigth = new Scanner(System.in);
                                    int total = weigth.nextInt();
                                    System.out.println("What is the wieght of goods [In kilograms] ?");
                                    Scanner weigthOfGoods = new Scanner(System.in);
                                    int totalGoods = weigthOfGoods.nextInt();
                                    System.out.println("Do type of good you want to transport?");
                                    Scanner typeG = new Scanner(System.in);
                                    String typeOfGoods = typeG.nextLine();
                                    System.out.println("Do type of toxic material do you have?");
                                    Scanner typeToxic = new Scanner(System.in);
                                    String typeOfToxicMaterial = typeToxic.nextLine();
                                    System.out.println("Do you have any sertificates on your goods?");
                                    Scanner sertificates = new Scanner(System.in);
                                    String sertificatesTypes = sertificates.nextLine();
                                    String nameOfContainer = shipsList.get(cont - 1).name;

                                    if (totalOfAllContainers + total < maxWeigth) {
                                        looseToxicContainer ltc = new looseToxicContainer(typeOfContainer, sender, goods, securityType, total, totalGoods, typeOfGoods, typeOfToxicMaterial, sertificatesTypes, nameOfContainer);
                                        ltc.toString();
                                        containerList.add(ltc);

                                        q5++;
                                    } else {
                                        System.out.println("[!] You have exceeded the weigth limit! We cannot top up that last container.");
                                        System.out.println();
                                        topUpWithContainers(false);
                                    }
                                }

                                System.out.println("Do you want to top up another containers");
                                Scanner answer = new Scanner(System.in);
                                String ans = answer.nextLine();
                                if (ans.equals("yes") || ans.equals("Yes")) {
                                    topUpWithContainers(false);
                                }

                                System.out.println("Topped up container on this ship : " + shipsList.get(cont - 1));
                                System.out.println(containerList);
                                break;

                            case 2:
                                for (int i = 0; i < n6; i++) {
                                    String typeOfContainer = "With toxic liquid goods";
                                    System.out.println("Who is a sender?");
                                    Scanner name = new Scanner(System.in);
                                    String sender = name.nextLine();
                                    System.out.println("What is tare?");
                                    Scanner tare = new Scanner(System.in);
                                    String goods = tare.nextLine();
                                    System.out.println("What Security you use?");
                                    Scanner security = new Scanner(System.in);
                                    String securityType = security.nextLine();
                                    System.out.println("What is the total weigth [In kilograms] ?");
                                    Scanner weigth = new Scanner(System.in);
                                    int total = weigth.nextInt();
                                    System.out.println("What is the wieght of goods [In kilograms] ?");
                                    Scanner weigthOfGoods = new Scanner(System.in);
                                    int totalGoods = weigthOfGoods.nextInt();
                                    System.out.println("Do type of good you want to transport?");
                                    Scanner typeG = new Scanner(System.in);
                                    String typeOfGoods = typeG.nextLine();
                                    System.out.println("Do type of toxic material do you have?");
                                    Scanner typeToxic = new Scanner(System.in);
                                    String typeOfToxicMaterial = typeToxic.nextLine();
                                    System.out.println("Do you have any sertificates on your goods?");
                                    Scanner sertificates = new Scanner(System.in);
                                    String sertificatesTypes = sertificates.nextLine();
                                    String nameOfContainer = shipsList.get(cont - 1).name;

                                    if (totalOfAllContainers + total < maxWeigth) {
                                        liquidToxicContainer liqtc = new liquidToxicContainer(typeOfContainer, sender, goods, securityType, total, totalGoods, typeOfGoods, typeOfToxicMaterial, sertificatesTypes, nameOfContainer);
                                        liqtc.toString();
                                        containerList.add(liqtc);

                                        q5++;
                                    } else {
                                        System.out.println("[!] You have exceeded the weigth limit! We cannot top up that last container.");
                                        System.out.println();
                                        topUpWithContainers(false);
                                    }
                                }
                                System.out.println("Do you want to top up another containers");
                                Scanner answer1 = new Scanner(System.in);
                                String ans1 = answer1.nextLine();
                                if (ans1.equals("yes") || ans1.equals("Yes")) {
                                    topUpWithContainers(false);
                                }

                                System.out.println("Topped up container on this ship : " + shipsList.get(cont - 1));
                                System.out.println(containerList);
                                break;
                        }

                    } else {
                        System.out.println("We cannot carry such a big ammount of containers because its very dangerous!");
                    }

                } else {
                    System.out.println("We are not able to top up such ammount of containers");
                }
                break;
        }

        } catch (Exception e) {
            System.out.println("You dont have any ship in the port. If you need to top up a ship press '3' ");
        }
    }

    public static List shopList = new ArrayList();

    public static List wagonList = new ArrayList();

    public static void unload() throws IOException {
        System.out.println("Where you want to upload you container" + "\n" + "[1] To the shop" + "\n" + "[2] On the wagon");
        Scanner s1 = new Scanner(System.in);
        int upload = s1.nextInt();

        switch (upload) {
            case 1:

                    for (int x = 0; x < containerList.size(); x++) {
                        System.out.println(containerList.get(x));
                    }
                    System.out.println("What container you want to remove?");
                    Scanner removeing = new Scanner(System.in);
                    int i = removeing.nextInt();

                    shopList.add(containerList.get(i - 1));
                    containerList.remove(i - 1);
                    System.out.println("[!] Write actual date(In format yyyy-mm-dd)");
                    Scanner date = new Scanner(System.in);
                    String actualdate = date.nextLine();
                    String actualdate1 = (actualdate.substring(0, 4) + "-" + actualdate.substring(5, 7) + "-" + actualdate.substring(8, 10));
                    LocalDate date11 = LocalDate.parse(actualdate1);
                    System.out.println(date11);
                    System.out.println("Do you want to move another container from a ship?");
                    Scanner sc = new Scanner(System.in);
                    String answer = sc.nextLine();
                    if (answer.equals("Yes") || answer.equals("yes")) {
                        unload();
                    } else {
                        menu();
                    }


                break;

            case 2:
                try {
                    for (int x = 0; x < containerList.size(); x++) {
                        System.out.println(containerList.get(x));
                    }
                    System.out.println("What container you want to remove?");
                    Scanner removing = new Scanner(System.in);
                    int q1 = removing.nextInt();
                    if (wagonList.size() > 10) {
                        long start = System.currentTimeMillis();
                        long end = (start+1000) + 29 * 1000;

                        do {
                            for(int wq = 0; wq < 1; wq++)
                            System.out.println("[!] Waiting for new wagon to arrive");
                        }
                        while (System.currentTimeMillis() < end);

                        do {
                            wagonList.clear();
                            System.out.println("[!] Now you can top up a container");
                            unload();
                        }
                        while (System.currentTimeMillis() > end);

                        }

                    wagonList.add(containerList.get(q1 - 1));
                    containerList.remove(q1 - 1);

                        System.out.println("Do you want to move another container from a ship?");
                        Scanner sc1 = new Scanner(System.in);
                        String answer1 = sc1.nextLine();
                        if (answer1.equals("Yes") || answer1.equals("yes")) {
                            unload();
                        } else {
                            menu();
                        }

                        break;
                }
                catch(Exception e){
                    System.out.println("[!] You don't have any container at the moment");
                }
                menu();
        }
    }
    public static List senderList = new ArrayList();

    public static void Sender() throws IOException {

try {
    System.out.println("What is your name?");
    Scanner sc = new Scanner(System.in);
    String name1 = sc.nextLine();
    System.out.println("What is your Surname?");
    Scanner sc1 = new Scanner(System.in);
    String surname1 = sc1.nextLine();
    System.out.println("What is number of your PESEL?");
    Scanner sc2 = new Scanner(System.in);
    String PESEL1 = sc2.nextLine();
    String birthday = ("20" + PESEL1.substring(0, 2) + "-" + PESEL1.substring(2, 4) + "-" + PESEL1.substring(4, 6));
    System.out.println("What is your adress?");
    Scanner sc3 = new Scanner(System.in);
    String adress1 = sc3.nextLine();
    LocalDate birthDate1 = LocalDate.parse(birthday);
    Sender sd = new Sender(name1, surname1, PESEL1, adress1, birthDate1);

    senderList.add(sd);

}catch (Exception e){
    System.out.println("Wrong PESEL format");
    Sender();
}

    }

    public static ArrayList<Ship> readShipsFromFile(String fileName) throws FileNotFoundException {

        File file = new File(fileName);
        Scanner s = new Scanner(file);

        ArrayList<Ship> ships = new ArrayList<Ship>();
        while (s.hasNextLine()){
            String line = s.nextLine();

            String[] shipProperties = line.split(".");


            System.out.println(shipProperties[0]);
            System.out.println(shipProperties[1]);
            System.out.println(shipProperties[2]);
            System.out.println(shipProperties[3]);
            System.out.println(shipProperties[4]);
            System.out.println(shipProperties[5]);
            System.out.println(shipProperties[6]);
        }
        return null;
    }


}
