import java.time.LocalDate;

public class Sender {
    String name1;
    String surname1;
    String PESEL1;
    String adress1;
    LocalDate birthDate1;

    public Sender(String name1, String surname1, String PESEL1, String adress1, LocalDate birthDate1){
        this.name1 = name1;
        this.surname1 = surname1;
        this.PESEL1 = PESEL1;
        this.adress1 = adress1;
        this.birthDate1 = birthDate1;
    }
    public String toString(){
        return "Name: " + name1 + ". Surname: " + surname1 + ". Pesel: " + PESEL1 + ". Adress: " + adress1 + ". Birth date: " + birthDate1;

    }
}
