class explosiveContainer
        extends heavyContainer {

    String typeOfExplosiveMaterial;

    public explosiveContainer(String typeOfContainer,String Sender, String tare, String security, int totalWeight, int weightOfProducts, String TypeOfAGood, String typeOfExplosiveMaterial, String InfoOfCertificates, String nameOfContainer) {
        super(typeOfContainer,Sender, tare, security, totalWeight, weightOfProducts, InfoOfCertificates, TypeOfAGood, nameOfContainer);
        this.typeOfExplosiveMaterial = typeOfExplosiveMaterial;

    }

}