
import java.io.IOException;

public class Port {
    public static void main(String args[]) throws IOException {

        //Part of creating a ship
        Ship ship = new Ship("Mary", "Odessa", "Portu", "Ukraine",
                3, 20, 5,
                100, 500000, 0);

        Ship ship1 = new Ship("Balta", "Odessa", "Turkey", "Ukraine",
                3, 15, 3,
                80, 400000, 0);

        Ship ship2 = new Ship("Argo", "Odessa", "Poland", "Ukraine",
                3, 15, 10,
                70, 350000, 0);

        Ship ship3 = new Ship("Pryluky", "Odessa", "Egypt", "Ukraine",
                3, 20, 2,
                120, 550000, 0);

        Ship ship4 = new Ship("Sagajdachny", "Odessa", "Romania", "Ukraine",
                3, 20, 5,
                100, 4700000, 0);

        Ship.menu();


    }
}
