import java.util.Random;
public  class basicContainer extends Container {
    String typeOfContainer;
    String Sender;
    String tare;
    String security;
    int totalWeight;
    int weightOfProducts;
    String InfoOfCertificates;
    String nameOfContainer;


    public String toString(){
        return "Type of container : " +typeOfContainer + ". The sender is: " + Sender + ". Tare is: " + tare + ". Security: " + security + ". Total weigth: " + totalWeight + ". Weigth of goods: " + weightOfProducts
                + ". Information about certificates: " + InfoOfCertificates + ". " + "Topped up on container: " + nameOfContainer + "\n";

    }



    public basicContainer(String typeOfContainer, String Sender, String tare, String security, int totalWeight, int weightOfProducts, String InfoOfCertificates, String nameOfContainer) {
        this.typeOfContainer = typeOfContainer;
        this.Sender = Sender;
        this.tare = tare;
        this.security = security;
        this.totalWeight = totalWeight;
        this.weightOfProducts = weightOfProducts;
        this.InfoOfCertificates = InfoOfCertificates;
        this.nameOfContainer = nameOfContainer;


    }
}
