public abstract class Container {


    public String typeOfContainer;



}
