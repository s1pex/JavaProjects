import java.util.Random;
import java.util.Scanner;

class coolingContainer
        extends heavyContainer {
    boolean energy;
    String TypeOfCooling;


    public coolingContainer(String typeOfContainer,String Sender, String tare ,String typeOfAGood, String security, int totalWeight, int weightOfProducts, String TypeOfCooling , String InfoOfCertificates, String nameOfContainer) {
        super(typeOfContainer,Sender, tare, security, totalWeight, weightOfProducts, InfoOfCertificates, typeOfAGood, nameOfContainer);
        this.TypeOfCooling = TypeOfCooling;

        this.energy = energy;

        Random rand = new Random();
        int n = rand.nextInt(1000);





    }
}