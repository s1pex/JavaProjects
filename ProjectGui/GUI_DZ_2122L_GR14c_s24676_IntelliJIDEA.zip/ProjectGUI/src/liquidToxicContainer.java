class liquidToxicContainer
        extends heavyContainer {

    String typeOfLiwuidToxicMaterial;

    public liquidToxicContainer(String typeOfContainer, String Sender, String tare, String security, int totalWeight, int weightOfProducts, String TypeOfAGood, String typeOfLiwuidToxicMaterial, String InfoOfCertificates, String nameOfContainer) {
        super(typeOfContainer,Sender, tare, security, totalWeight, weightOfProducts, InfoOfCertificates, TypeOfAGood, nameOfContainer);
        this.typeOfLiwuidToxicMaterial = typeOfLiwuidToxicMaterial;
    }


}