class Shop{

    int maxNumOfContainers;
    String shopName;

    public Shop(String shopName, int maxNumOfContainers){
        this.shopName = shopName;
        this.maxNumOfContainers = maxNumOfContainers;
    }

}