class looseToxicContainer
        extends heavyContainer {

   String typeOfLooseToxicMaterial;
    public looseToxicContainer(String typeOfContainer,String Sender, String tare, String security, int totalWeight, int weightOfProducts, String TypeOfAGood, String typeOfLooseToxicMaterial, String InfoOfCertificates, String nameOfContainer) {
        super(typeOfContainer,Sender, tare, security, totalWeight, weightOfProducts, InfoOfCertificates, TypeOfAGood, nameOfContainer);
        this.typeOfLooseToxicMaterial = typeOfLooseToxicMaterial;
    }


}