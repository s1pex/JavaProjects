class heavyContainer
        extends basicContainer {

    String typeOfAGood;


    public heavyContainer(String typeOfContainer,String Sender, String tare, String security, int totalWeight, int weightOfProducts, String InfoOfCertificates, String typeOfAGood, String nameOfContainer) {
        super(typeOfContainer,Sender, tare, security, totalWeight, weightOfProducts, InfoOfCertificates, nameOfContainer);
        this.typeOfAGood = typeOfAGood;

    }


}