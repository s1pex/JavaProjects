/**
 * @author Raksha Vladyslav S24676
 */

package zad1;

public interface Mapper<A> {
    A map(A x);
}  
