/**
 *
 *  @author Raksha Vladyslav S24676
 *
 */

package zad1;

public interface Selector<A> {
     boolean sel(A x);
}
