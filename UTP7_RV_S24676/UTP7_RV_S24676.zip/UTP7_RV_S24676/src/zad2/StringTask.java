package zad2;

public class StringTask {

    public StringTask(String letter, int multiplyNum){

    }

    public String getResult(){

    }
    public TaskState getState() {

    }

    public void start() {

    }

    public void abort(){

    }
    public boolean isDone(){

    }
}
